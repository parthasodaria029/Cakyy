import React from 'react';

export default function DashboardScreen() {
  return <div>DashboardScreen</div>;
}