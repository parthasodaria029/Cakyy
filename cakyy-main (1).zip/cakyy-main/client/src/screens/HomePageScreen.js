import React from 'react'
import "./Home.css";
export default function Home() {


  
  return (
    <>
    <section className="home" id="home">
        <div className="homeContent">
            <h2>Making Every Celebration With Cakyy  </h2>
            <p>Without Cakes Party like Just meeting</p>
            {/* <div className="home-btn">
                <a href="/"><button>see more</button></a>
            </div> */}
        </div>
    </section>

    
    </>
  )
}


